//
//  NavigationIntegrationHelper.swift
//  GuideLight v3
//
//  Navigation integration helper for ARWorldMap support
//

import Foundation
import SwiftUI
import ARKit
import Combine

// MARK: - Navigation Integration Helper
class NavigationIntegrationHelper: ObservableObject {
    static let shared = NavigationIntegrationHelper()
    
    // MARK: - Private constants
    /// Use a private alias to avoid symbol ambiguity.
    private let GLMapSelectedNote = Notification.Name("GuideLight.MapSelectedForNavigation")
    
    @Published var selectedMapForNavigation: JSONMap?
    @Published var isARWorldMapLoaded = false
    @Published var loadingProgress: String = ""
    
    private var mapManager = SimpleJSONMapManager.shared
    private var cancellables = Set<AnyCancellable>()
    
    private init() {
        setupNotificationListeners()
    }
    
    // MARK: - Notification Listeners
    private func setupNotificationListeners() {
        NotificationCenter.default
            .publisher(for: GLMapSelectedNote)
            .sink { [weak self] notification in
                self?.handleMapSelectionChange(notification)
            }
            .store(in: &cancellables)
    }
    
    private func handleMapSelectionChange(_ notification: Notification) {
        guard let userInfo = notification.userInfo,
              let mapId = userInfo["mapId"] as? UUID else {
            selectedMapForNavigation = nil
            isARWorldMapLoaded = false
            return
        }
        
        if let map = mapManager.maps.first(where: { $0.id == mapId }) {
            selectedMapForNavigation = map
            print("📍 Navigation Helper: Map selected - \(map.name)")
            print("   Has ARWorldMap: \(map.hasARWorldMap)")
        }
    }
    
    // MARK: - ARWorldMap Loading
    func loadARWorldMapForNavigation(completion: @escaping (Result<ARWorldMap, ARWorldMapError>) -> Void) {
        guard let map = selectedMapForNavigation else {
            completion(.failure(.fileNotFound))
            return
        }
        
        guard map.hasARWorldMap else {
            completion(.failure(.fileNotFound))
            return
        }
        
        loadingProgress = "Loading ARWorldMap for navigation..."
        isARWorldMapLoaded = false
        
        mapManager.loadARWorldMap(for: map) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let worldMap):
                    self?.isARWorldMapLoaded = true
                    self?.loadingProgress = "ARWorldMap loaded successfully"
                    print("✅ Navigation Helper: ARWorldMap loaded for navigation")
                    completion(.success(worldMap))
                    
                case .failure(let error):
                    self?.isARWorldMapLoaded = false
                    self?.loadingProgress = "Failed to load ARWorldMap"
                    print("❌ Navigation Helper: Failed to load ARWorldMap - \(error)")
                    completion(.failure(error))
                }
            }
        }
    }
    
    // MARK: - Map Data Access
    func getNavigationMapData() -> [String: Any]? {
        return selectedMapForNavigation?.jsonData
    }
    
    func getNavigationMapName() -> String? {
        return selectedMapForNavigation?.name
    }
    
    func hasARWorldMapSupport() -> Bool {
        return selectedMapForNavigation?.hasARWorldMap ?? false
    }
    
    // MARK: - Clear Selection
    func clearNavigationMap() {
        selectedMapForNavigation = nil
        isARWorldMapLoaded = false
        loadingProgress = ""
        mapManager.selectMapForNavigation(nil)
    }
    
    // MARK: - Parse IndoorMap from JSONMap
    static func parseIndoorMap(from jsonMap: JSONMap) -> IndoorMap? {
        guard let mapName = jsonMap.jsonData["mapName"] as? String else {
            print("❌ Failed to parse map: Missing mapName")
            return nil
        }
        
        // Parse rooms
        var rooms: [Room] = []
        if let roomsData = jsonMap.jsonData["rooms"] as? [[String: Any]] {
            for roomDict in roomsData {
                guard let name = roomDict["name"] as? String,
                      let typeString = roomDict["type"] as? String,
                      let floorSurfaceString = roomDict["floorSurface"] as? String,
                      let roomType = RoomType(rawValue: typeString),
                      let floorSurface = FloorSurface(rawValue: floorSurfaceString) else {
                    continue
                }
                
                let room = Room(name: name, type: roomType, floorSurface: floorSurface)
                rooms.append(room)
            }
        }
        
        // Parse beacons
        var beacons: [Beacon] = []
        if let beaconsData = jsonMap.jsonData["beacons"] as? [[String: Any]] {
            for beaconDict in beaconsData {
                guard let name = beaconDict["name"] as? String,
                      let categoryString = beaconDict["category"] as? String,
                      let category = BeaconCategory(rawValue: categoryString),
                      let roomId = beaconDict["roomId"] as? String,
                      let coordsDict = beaconDict["coordinates"] as? [String: Double],
                      let x = coordsDict["x"],
                      let y = coordsDict["y"],
                      let z = coordsDict["z"] else {
                    continue
                }
                
                let position = simd_float3(Float(x), Float(y), Float(z))
                let audioLandmark = beaconDict["audioLandmark"] as? String
                let isAccessible = beaconDict["isAccessible"] as? Bool ?? true
                
                // Physical properties
                var physicalProperties: PhysicalProperties?
                if let propsDict = beaconDict["physicalProperties"] as? [String: Any],
                   let isObstacle = propsDict["isObstacle"] as? Bool,
                   isObstacle,
                   let boundingBoxDict = propsDict["boundingBox"] as? [String: Double],
                   let width = boundingBoxDict["width"],
                   let depth = boundingBoxDict["depth"],
                   let height = boundingBoxDict["height"],
                   let avoidanceRadius = propsDict["avoidanceRadius"] as? Double,
                   let obstacleTypeString = propsDict["obstacleType"] as? String,
                   let obstacleType = ObstacleType(rawValue: obstacleTypeString) {
                    
                    physicalProperties = PhysicalProperties(
                        isObstacle: true,
                        boundingBox: BoundingBox(
                            width: Float(width),
                            depth: Float(depth),
                            height: Float(height)
                        ),
                        avoidanceRadius: Float(avoidanceRadius),
                        canRouteAround: propsDict["canRouteAround"] as? Bool ?? true,
                        obstacleType: obstacleType
                    )
                }
                
                let beacon = Beacon(
                    name: name,
                    position: position,
                    category: category,
                    roomId: roomId,
                    description: beaconDict["description"] as? String,
                    audioLandmark: audioLandmark,
                    isAccessible: isAccessible,
                    accessibilityNotes: beaconDict["accessibilityNotes"] as? String,
                    physicalProperties: physicalProperties
                )
                beacons.append(beacon)
            }
        }
        
        // Parse doorways
        var doorways: [Doorway] = []
        if let doorwaysData = jsonMap.jsonData["doorways"] as? [[String: Any]] {
            for doorwayDict in doorwaysData {
                guard let name = doorwayDict["name"] as? String,
                      let posDict = doorwayDict["position"] as? [String: Double],
                      let x = posDict["x"],
                      let y = posDict["y"],
                      let z = posDict["z"],
                      let width = doorwayDict["width"] as? Double,
                      let connectsDict = doorwayDict["connectsRooms"] as? [String: String],
                      let roomA = connectsDict["roomA"],
                      let roomB = connectsDict["roomB"],
                      let doorTypeString = doorwayDict["doorType"] as? String,
                      let doorType = DoorwayType(rawValue: doorTypeString),
                      let actionsDict = doorwayDict["doorActions"] as? [String: String],
                      let fromAString = actionsDict["fromRoomA"],
                      let fromBString = actionsDict["fromRoomB"],
                      let fromRoomA = DoorAction(rawValue: fromAString),
                      let fromRoomB = DoorAction(rawValue: fromBString) else {
                    continue
                }
                
                let position = simd_float3(Float(x), Float(y), Float(z))
                let isAccessible = doorwayDict["isAccessible"] as? Bool ?? true
                
                let doorway = Doorway(
                    name: name,
                    position: position,
                    width: Float(width),
                    height: Float(doorwayDict["height"] as? Double ?? 2.1),
                    connectsRooms: ConnectedRooms(roomA: roomA, roomB: roomB),
                    doorType: doorType,
                    doorActions: DoorActions(fromRoomA: fromRoomA, fromRoomB: fromRoomB),
                    isAccessible: isAccessible,
                    description: doorwayDict["description"] as? String,
                    audioLandmark: doorwayDict["audioLandmark"] as? String
                )
                doorways.append(doorway)
            }
        }
        
        // Parse waypoints
        var waypoints: [Waypoint] = []
        if let waypointsData = jsonMap.jsonData["waypoints"] as? [[String: Any]] {
            for waypointDict in waypointsData {
                guard let name = waypointDict["name"] as? String,
                      let coordsDict = waypointDict["coordinates"] as? [String: Double],
                      let x = coordsDict["x"],
                      let y = coordsDict["y"],
                      let z = coordsDict["z"],
                      let roomId = waypointDict["roomId"] as? String else {
                    continue
                }
                
                let coordinates = simd_float3(Float(x), Float(y), Float(z))
                let waypointTypeString = waypointDict["waypointType"] as? String ?? "navigation"
                let waypointType = Waypoint.WaypointType(rawValue: waypointTypeString) ?? .navigation
                let isAccessible = waypointDict["isAccessible"] as? Bool ?? true
                
                let waypoint = Waypoint(
                    name: name,
                    coordinates: coordinates,
                    roomId: roomId,
                    waypointType: waypointType,
                    isAccessible: isAccessible,
                    description: waypointDict["description"] as? String,
                    audioLandmark: waypointDict["audioLandmark"] as? String
                )
                waypoints.append(waypoint)
            }
        }
        
        let indoorMap = IndoorMap(
            name: mapName,
            description: jsonMap.jsonData["description"] as? String,
            rooms: rooms,
            beacons: beacons,
            doorways: doorways,
            waypoints: waypoints
        )
        
        print("✅ Parsed IndoorMap: \(mapName)")
        print("   Rooms: \(rooms.count)")
        print("   Beacons: \(beacons.count)")
        print("   Doorways: \(doorways.count)")
        print("   Waypoints: \(waypoints.count)")
        
        return indoorMap
    }
}

// MARK: - Navigation Status View
struct NavigationMapStatusView: View {
    @ObservedObject private var navigationHelper = NavigationIntegrationHelper.shared
    
    var body: some View {
        Group {
            if let map = navigationHelper.selectedMapForNavigation {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image(systemName: "location.circle.fill")
                            .foregroundColor(.green)
                            .font(.title2)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Active Navigation Map")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(map.name)
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            if map.hasARWorldMap {
                                Label("ARWorldMap Available", systemImage: "cube.fill")
                                    .font(.caption2)
                                    .foregroundColor(.blue)
                            }
                        }
                        
                        Spacer()
                    }
                    
                    if let beacons = map.jsonData["beacons"] as? [Any],
                       let doorways = map.jsonData["doorways"] as? [Any] {
                        HStack(spacing: 16) {
                            Label("\(beacons.count)", systemImage: "flag.fill")
                                .font(.caption)
                                .foregroundColor(.green)
                            
                            Label("\(doorways.count)", systemImage: "door.left.hand.open")
                                .font(.caption)
                                .foregroundColor(.orange)
                        }
                    }
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(12)
            } else {
                VStack(alignment: .center, spacing: 8) {
                    Image(systemName: "map.circle")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                    
                    Text("No Navigation Map Selected")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    
                    Text("Select a map to enable navigation")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding()
            }
        }
    }
}
