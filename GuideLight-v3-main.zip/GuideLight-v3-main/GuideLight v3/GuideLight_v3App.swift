//
//  GuideLight_v3App.swift
//  GuideLight v3
//
//  Created by Indraneel Rakshit on 9/21/25.
//

import SwiftUI

@main
struct GuideLight_v3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
